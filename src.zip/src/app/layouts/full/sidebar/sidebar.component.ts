import { ChangeDetectorRef, Component, OnDestroy } from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { MenuItems } from '../../../shared/menu-items/menu-items';
import { NestedTreeControl } from '@angular/cdk/tree';
import { MatTreeNestedDataSource } from '@angular/material';
import { Router } from '@angular/router';


interface MenuNode {
  children?: MenuNode[];
  menuname: string;
  routerUrl: string;
}


const MENU_DATA: MenuNode[] = [
  {
    menuname: 'User',
    routerUrl:'/configuration/user-management',
  },
  // {
  //   menuname: 'Configuration',
  //   routerUrl:'/',
  //   children : [
  //     {
  //       menuname: 'User Management',
  //       routerUrl:'/configuration/user-management'
  //     }
  //   ]
  // }
]; 


@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: []
})
export class AppSidebarComponent implements OnDestroy {
  mobileQuery: MediaQueryList;

  private _mobileQueryListener: () => void;

  menuTreeControl = new NestedTreeControl<MenuNode>(node=> node.children);
  menuDataSource = new MatTreeNestedDataSource<MenuNode>();

  constructor(
    changeDetectorRef: ChangeDetectorRef,
    media: MediaMatcher,
    public menuItems: MenuItems,private router : Router
  ) {
    this.mobileQuery = media.matchMedia('(min-width: 768px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
    this.menuDataSource.data = MENU_DATA;
  }

  ngOnInit() {
    // if (node.Children && node.Children.find(c => c.UniqueId === uniqueId)) {
    //   this.treeControl.expand(node);
    //   this.expand(this.dataSource.data, node.UniqueId);
    // }

    this.menuDataSource.data.forEach(mainMenu => {
      // console.log('elements inside for each loop',element);
      mainMenu.children?.forEach(link => {
        // console.log("chiledrens inside child for each loop::",element1);
       if(link['routerUrl'] == this.router.url) {
        //  console.log("you are in right location ::",element1['routerUrl']);
         this.menuTreeControl.expand(mainMenu);
       }

      });
    });
  }

  hasChild = (_: number, node: MenuNode) => !!node.children && node.children.length > 0;

  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }
  getMenu(node:any){
   if (node.menuname == 'Logs') {
  //  this.openinbrowserclicked();
   } else if(node.menuname == 'Performance & Availability'){
  //  this.openinbrowserclicked();
   }
    
  }
  openinbrowserclicked() {
    window.open(
      'https://stackoverflow.com/questions/47398714/how-can-we-have-multiple-datepickers-in-angular-material',
      '_blank'
    );
  }
}

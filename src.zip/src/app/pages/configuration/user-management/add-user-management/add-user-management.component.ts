import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogConfig, MatDialogRef, MAT_DIALOG_DATA, ThemePalette } from '@angular/material';
import { ToasterService } from 'angular2-toaster';
import { DialogMessages, Message } from 'app/common/constants/messages';
import { AlertComponent } from 'app/common/dialog/alert/alert.component';
import { COMMA, DOWN_ARROW, ENTER, ESCAPE, TAB } from '@angular/cdk/keycodes';
@Component({
  selector: 'app-add-user-management',
  templateUrl: './add-user-management.component.html',
  styleUrls: ['./add-user-management.component.css']
})
export class AddUserManagementComponent implements OnInit {
  form !: FormGroup;
  @ViewChild('picker') picker: any;
  public date = new Date();
  public disabled = false;
  public showSpinners = true;
  public showSeconds = false;
  public touchUi = false;
  public enableMeridian = true;
  public minDate !: moment.Moment;
  public maxDate = new Date();
  public stepHour = 1;
  public stepMinute = 1;
  public stepSecond = 1;
  public hideTime = true;
  public color : ThemePalette = 'primary';
  gender:boolean = false;
  formErrors :any = {
    'name': '',
    'emailAddress': '',
  };
  validationMessages:any = {
    'name': {
      'required': ' Enter Name',
      'maxlength': 'Enter less than 100 characters',
    },
    'emailAddress': {
      'required': ' Enter Email Address',
      'email':'Enter Valid Email Address'
    },
  };
//  errorRule
loading:boolean = false;
title:any = 'Create';
user:any;
selectedLanguages:any = ['English(UK)', 'Latin'];
separatorKeysCodes = [ENTER, COMMA];
addOnBlur: boolean = true;
selectable1: boolean = true;
removable1: boolean = true;
selectable2: boolean = true;
removable2: boolean = true;
  constructor(private fb : FormBuilder,private dialog: MatDialog,
    private dialogref: MatDialogRef<AddUserManagementComponent>, @Inject(MAT_DIALOG_DATA) data:any) {
      this.title = data.dialogData.title ? data.dialogData.title : this.title;
      this.user = data.userData;
  }

  ngOnInit(): void {
    if (this.user == 'null') {
      this.buildAddForm();
    } else {
      this.buildEditForm(this.user);
    }
  }
 /**
   * method to build form create certificate
   * @returns void
   */
  buildAddForm(): void {
    this.form = this.fb.group({
      name: ['', [Validators.required]],
      birthDate: [this.date, [Validators.required]],
      gender: ['', [Validators.required]],
      language: ['', [Validators.required]],
      about: ['', [Validators.required]],
    });
    this.form.valueChanges.subscribe(data => this.onValueChanged(data));
    this.onValueChanged();
  }

  buildEditForm(data:any): void {
    this.form = this.fb.group({
      name: [data.name, [Validators.required]],
      birthDate: [this.date, [Validators.required]],
      gender: [data.gender, [Validators.required]],
      language: [data.language, [Validators.required]],
      about: [data.about, [Validators.required]],
    });
    this.form.valueChanges.subscribe(data => this.onValueChanged(data));
    this.onValueChanged();
  }
   /**
   * /method to validate project form 
   * @param  {any} data?
   * @returns void
   */
  onValueChanged(data?: any) {
    if (!this.form) {
      return;
    }
    const form1 = this.form;
    for (const field in this.formErrors) {
      if (Object.prototype.hasOwnProperty.call(this.formErrors, field)) {
        this.formErrors[field] = '';
        const control = form1.get(field);
        if (control && control.dirty && !control.valid) {
          const messages = this.validationMessages[field];
          for (const key in control.errors) {
            if (Object.prototype.hasOwnProperty.call(control.errors, key)) {
              this.formErrors[field] += messages[key] + ' ';
            }
          }
        }
      }
    }
  }
  create(){
  
  }
edit(){
  
}

  /**
     * method to restrict to add more than one space in input field
     * @param  {} event
     * @returns boolean
     */
    spaceButton(event:any) {
      if (event.which === 32 && event.target.value === '') {
        return false;
      }
    }
    /**
   * method to close project dialog
   * @returns void
   */
  close(): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data =  {
      title: DialogMessages.confirmation_title,
      subTitle: DialogMessages.discard_changes,
      buttonCancelName: DialogMessages.confirmation_button_cancel,
      buttonConfirmName: DialogMessages.confirmation_button_discard,
    }
    let dialogRef = this.dialog.open(AlertComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
      if (result == 'confirm') {
        this.dialogref.close();
      }
    })
  }
 

  remove(keyword: any): void {
    let index = this.selectedLanguages.indexOf(keyword);

    if (index >= 0) {
      this.selectedLanguages.splice(index, 1);
    }
  }
  dateChange(){
   
    }
}

import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSort, MatTableDataSource, MatPaginator, MatDialogConfig, MatDialog } from '@angular/material';
import { DialogMessages, Message } from '../../../common/constants/messages';
import { AlertComponent } from 'app/common/dialog/alert/alert.component';
import { FormControl } from '@angular/forms';
import { ApiService } from 'app/common/services/httpcalls/api.service';
import { ToasterService } from 'angular2-toaster';
import { AddUserManagementComponent } from './add-user-management/add-user-management.component';

const CONTACT_DATA: any[] = [
  { name: 'Richard Lovelace',birthDate:'December 10, 1815', language:'Spanish, Latin', gender: 'Male', about: 'Multiline Textarea'},
  { name: 'Grace Hopper',birthDate:'December 09, 1906', language:'English(UK)', gender: 'Female', about: 'Multiline Textarea'},
  { name: 'Richard Lovelace',birthDate:'December 10, 1815', language:'Spanish, Latin', gender: 'Male', about: 'Multiline Textarea'},
  { name: 'Richard Lovelace',birthDate:'December 10, 1815', language:'Spanish, Latin', gender: 'Male', about: 'Multiline Textarea'},
];

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.css']
})
export class UserManagementComponent implements OnInit {

  userDisplayedColumns: string[] = ['name','birthDate', 'language', 'gender'];
  userDataSource = new MatTableDataSource(CONTACT_DATA);

  @ViewChild(MatSort) sort!: MatSort;  // ! is added to resolve typeStrict issue of angular
  @ViewChild(MatPaginator) paginator!: MatPaginator;
 
  loading:boolean =false;
  constructor(private dialog: MatDialog) { 
    
  }

  ngOnInit(): void {
  }

  ngAfterViewInit() {
    this.userDataSource.sort = this.sort;
    this.userDataSource.paginator = this.paginator;
  }
 
  openUserDialog(data:any, action:any){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "600px";
    dialogConfig.data = {
        dialogData: { title: action },
        userData: data
    }
    const dialogRef = this.dialog.open(AddUserManagementComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(
        data => {
            if (data && data.action) {
              // this.getUsers();
            }
        }
    );
  }
 

}

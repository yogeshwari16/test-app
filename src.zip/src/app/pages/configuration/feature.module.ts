import { NgModule } from '@angular/core';
import { CommonModule, PathLocationStrategy } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FeatureRoutes } from './feature.routing';
import { DemoMaterialModule } from 'app/demo-material-module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { ngxLoadingAnimationTypes, NgxLoadingModule } from 'ngx-loading';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { UserManagementComponent } from './user-management/user-management.component';
import { AddUserManagementComponent } from './user-management/add-user-management/add-user-management.component';
import { NgxMatDatetimePickerModule, NgxMatTimepickerModule,NgxMatNativeDateModule } from '@angular-material-components/datetime-picker';
import { ProgressbarComponent } from './user-management/progressbar/progressbar.component';
@NgModule({
  declarations: [
    UserManagementComponent,
    AddUserManagementComponent,
    ProgressbarComponent],
  imports: [
    CommonModule,
    MatFormFieldModule, 
    DemoMaterialModule,
    FlexLayoutModule,ReactiveFormsModule,FormsModule,
    RouterModule.forChild(FeatureRoutes),
    MatInputModule,
    NgxMatDatetimePickerModule,
    NgxMatTimepickerModule,
    NgxMatNativeDateModule,
    NgxLoadingModule.forRoot({
      animationType: ngxLoadingAnimationTypes.threeBounce,
      backdropBackgroundColour: 'rgba(0,0,0,0.1)',
      backdropBorderRadius: '3px',
      primaryColour: '#4393e8',
      secondaryColour: '#4393e8',
      tertiaryColour: '#4393e8'
    }),
  
  ],
  providers: [
    {
      provide: LocationStrategy,
      useClass: HashLocationStrategy
    }
  ],
  entryComponents: [AddUserManagementComponent],
    schemas: [
      CUSTOM_ELEMENTS_SCHEMA
    ]
})
export class FeatureModule { }

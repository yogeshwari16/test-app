import { Routes } from '@angular/router';
import { UserManagementComponent } from './user-management/user-management.component';
export const FeatureRoutes: Routes = [
  {
    path: '',
    component: UserManagementComponent
  },
  {
    path: 'user-management',
    component: UserManagementComponent
  },
];
import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

// alert dialog box component
@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.css']
})
export class AlertComponent implements OnInit {
  title: null;
  ischecked = false
  subTitle: string = "Confirm";
  buttonCancelName: string = "Cancel";
  buttonConfirmName: string = "Ok";
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    private dialogref: MatDialogRef<AlertComponent>) {
    if (data) {
      this.title = data.title ? data.title : this.title;
      this.subTitle = data.subTitle ? data.subTitle : '';
      this.buttonCancelName = data.buttonCancelName ? data.buttonCancelName : this.buttonCancelName;
      this.buttonConfirmName = data.buttonConfirmName ? data.buttonConfirmName : this.buttonConfirmName;
    }
  }

  ngOnInit() {
  }
  /**
   * method to close alert dialog
   * @returns void
   */
   
  close(): void {
    this.dialogref.close();
  }
 
}

import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-success',
  templateUrl: './success.component.html',
  styleUrls: ['./success.component.css']
})
export class SuccessComponent implements OnInit {

  title: string = "Success";
  subTitle:any;
  htmlTitle:any;
  buttonConfirmName: string = "Ok";
  constructor(@Inject(MAT_DIALOG_DATA) public data: any) {
    if (data) {
      this.title = data.title ? data.title : this.title;
      this.subTitle = data.subTitle ? data.subTitle : this.subTitle;
      this.htmlTitle = data.htmlTitle ? data.htmlTitle : this.htmlTitle;
      this.buttonConfirmName = data.buttonConfirmName ? data.buttonConfirmName : this.buttonConfirmName;
    }
  }

  ngOnInit() {
  }

}

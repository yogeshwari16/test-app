import { Host } from "./host";
export class Api {
    public static readonly JOB_SERVICE_ACCESS: string = `${Host.HOSTURL}/accessControl/getJobServiceAccessList`;
    public static readonly EXPORT_USECASE_ACCESS: string = `${Host.HOSTURL}/accessControl/getExportUsecaseAccessList`;
    public static readonly GET_ALL_CONTACT: string =`${Host.HOSTURL}/getAllContact`;
    public static readonly ADD_CONTACT: string=`${Host.HOSTURL}/addContact`;
    public static readonly JOB_REPORT: string = `${Host.HOSTURL}/jobReport/getJobReportList`;
    public static readonly SYSTEMS: string = `${Host.HOSTURL}/externalSystem`;
    public static readonly JOB_MONITORING_GET: string = `${Host.HOSTURL}/jobMonitoringConfg/getAll`;
    public static readonly CONTACTS: string = `${Host.HOSTURL}/contact`;
    public static readonly TEAMCENTER_CONNECTIVITY: string = `${Host.HOSTURL}/getContacts`;
    public static readonly FMS_TEST: string = `${Host.HOSTURL}/getContacts`;
    public static readonly JOB_SERVICES: string = `${Host.HOSTURL}/jobServiceConfg`;
    public static readonly ERROR_RULE: string = `${Host.HOSTURL}/errorRulesConfg`;
    public static readonly JOB_SCHEDULAR: string = `${Host.HOSTURL}/jobSchedulerConfig`;
    //connect configuration
    public static readonly GET_CONFIGURATION_PROFILE : string = `${Host.HOSTURL}/connectConfiguration/getConfigurationProfiles`;    
    public static readonly GET_CONFIGURATION_BY_PROFILE : string = `${Host.HOSTURL}/connectConfiguration/getConnectConfigurationByProfile`;    
    public static readonly UPDATE_CONNECT_CONFIGURATION : string = `${Host.HOSTURL}/connectConfiguration/updateConnectConfiguration`;    
    public static readonly DELETE_CONNECT_CONFIGURATION : string = `${Host.HOSTURL}/connectConfiguration/delete`;    
    public static readonly GET_ERROR_RULE_DETAILS : string = `${Host.HOSTURL}/errorRulesConfg/getAll`;    
    public static readonly SUMMARY_REPORT : string = `${Host.HOSTURL}/jobSammary/getJobSammary`;
    public static readonly USERS: string = `${Host.HOSTURL}/user`; 
}


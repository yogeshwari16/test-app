export class Host {
    public static readonly APPNAME: string = "easyJobPost";
  //    public static readonly HOSTNAME: string = "localhost";
  //   public static readonly PORT: string = "3000";
  //   public static readonly HOSTURL: string = "http://localhost:3000/api";
  // public static readonly IMAGE_URL: string = "http://localhost:3000";
    
public static readonly HOSTNAME: string = "13.234.106.146";
public static readonly PORT: string = "3005";
//baseUrl: "http://localhost:8087/dashboard/" 
//  localhost:8087/dashboard/

public static readonly HOSTURL: string = "http://localhost:8087/dashboard";
public static readonly IMAGE_URL: string = "http://13.234.106.146:3005";

}

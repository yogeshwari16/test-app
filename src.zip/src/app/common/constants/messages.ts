export class Message {
    public static readonly error_title: string = "Error";
    public static readonly success_title: string = "Success";
    public static readonly warning_title: string = "Warning";
    public static readonly info_title: string = "Information";
    public static readonly server_error: string = "Server error";
    public static readonly add_title: string = "ADDED SUCCESSFULLY";
    public static readonly update_title: string = "UPDATED SUCCESSFULLY";
    public static readonly delete_title: string = "DELETED SUCCESSFULLY";
}
export class DialogMessages {
    public static readonly confirmation_title: string = "Confirmation";
    public static readonly warning_title: string = "Any skill not found!";
    public static readonly confirmation_subtitle_logout: string = "Are you sure you want Logout?";
    public static readonly confirmation_button_cancel: string = "No Thanks";
    public static readonly confirmation_button_ok: string = "Delete";
    public static readonly confirmation_button_ok1: string = "Ok";
    public static readonly confirmation_button_cancel1: string = "Cancel";
    public static readonly goto_skill: string = "Go to Skill";
    public static readonly confirmation_button_logout: string = "Logout";
    public static readonly confirmation_button_discard: string = "Discard";
    public static readonly confirmation_button_reset: string = "Reset";
    public static readonly confirmation_button_update: string = "Update";
    public static readonly confirm_delete_contact: string = "Are you sure you want to delete contact?";
    public static readonly confirm_delete_job_service_configuration: string = "Are you sure you want to delete job Preference?";
    public static readonly discard_changes: string = "Are you sure you want to discard your changes?";
    public static readonly delete_error_rule: string = "Are you sure you want to delete error rule?";
    public static readonly delete_job_schedular: string = "Are you sure you want to delete job schedular?";
}

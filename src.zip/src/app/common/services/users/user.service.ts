import { Injectable } from '@angular/core';
import { Host } from '../../constants/host';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  userNameKey: string = `${Host.APPNAME}_userName`;
  userIdkey: string = `${Host.APPNAME}_userId`;
  JWTTokenKey: string = `${Host.APPNAME}_jwtToken`;
  isPinnedKey: string = `${Host.APPNAME}_isPinned`;
  userEmailIdKey: string = `${Host.APPNAME}_userEmailId`;
  userApplicationRoleKey: string = `${Host.APPNAME}_role`;
  interviewerRoleKey: string = `easyJobPost_role`;
  JWTTokenKeyEasyJobPost: string = `easyJobPost_jwtToken`;
  InterviewId: string = `easyJobPost_interviewId`;
  constructor() { }
  saveUserName(userName: string) {
    localStorage.setItem(this.userNameKey, userName);
  }
 

  removeAll() {
    localStorage.removeItem(this.userNameKey);
    localStorage.removeItem(this.userIdkey);
    localStorage.removeItem(this.JWTTokenKey);
    localStorage.removeItem(this.isPinnedKey);
    localStorage.removeItem(this.userEmailIdKey);
    localStorage.removeItem(this.userApplicationRoleKey);
  }
}
